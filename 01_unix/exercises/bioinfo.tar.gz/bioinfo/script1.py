#!/usr/bin/python
print "Running a simple Python script\n";
